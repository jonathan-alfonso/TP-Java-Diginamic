package fr.algorithmie;

import java.util.Scanner;

public class InteractifPlusMoins {

	public static void main(String[] args) {

		// G�n�ration nombre al�atoire
		double randomDbl = Math.random() * 100;
		int randomInt = (int) Math.round(randomDbl);
		System.out.println("Random : " + randomInt);
		
		// Scan de l'input
		System.out.print("Devinez le nombre : ");
		try (Scanner scan = new Scanner(System.in)) {
			int inputNbr = scan.nextInt();
			int tries = 1;
			
			while (inputNbr != randomInt) {
				if (inputNbr > randomInt) {
					System.out.println("Trop haut ! Recommencez : ");
					inputNbr = scan.nextInt();
				} else if (inputNbr < randomInt) {
					System.out.println("Trop bas ! Recommencez : ");
					inputNbr = scan.nextInt();
				}
				tries++;
			}
			
			if (inputNbr == randomInt) {
				System.out.println("Bravo, vous avez trouv� en " + tries + " coups.");
			}
		}
	}

}
