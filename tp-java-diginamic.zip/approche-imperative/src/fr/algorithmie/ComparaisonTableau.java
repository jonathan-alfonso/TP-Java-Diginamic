package fr.algorithmie;

public class ComparaisonTableau {

	public static void main(String[] args) {

		int[] array1 = {1, 15, -3, 8, 7, 4, -2, 28, -1, 17, 2, 3, 0, 14, -4, 5961} ;
		int[] array2 = {3, -8, 17, 5, -1, 4, 0, 6, 2, 11, -5, -4, 8, 5961} ;
		int cmnNbr = 0;
		
		// Recherche �l�ments et ajout du nombre dans une variable
		for (int i = 0; i < array1.length; i++) {
			for (int k = 0; k < array2.length; k++) {
				if (array1[i] == array2[k]) {
					cmnNbr += 1;
				}
			}
		}
		
		System.out.print("�l�ments en commun : " + cmnNbr);
		
		
			
		
		
		
		
	}

}
