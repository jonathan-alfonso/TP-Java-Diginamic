package fr.algorithmie;

import java.util.Scanner;

public class InteractifTantQue {

	public static void main(String[] args) {

		// Demande un nombre et scanne l'input
		System.out.println("Entrez un nombre compris entre 1 et 10 : ");
		try (Scanner scanner = new Scanner(System.in)) {
			int inputNbr = scanner.nextInt();
			
			 // Boucle while, tant que le nombre entr� est inf�rieur � 1 ou sup�rieur � 0, 
			 // demande une nouvelle entr�e 
			 while (inputNbr < 1 || inputNbr > 10) {
				System.out.println("Entrez un nombre compris entre 1 et 10 : ");
				inputNbr = scanner.nextInt();
				
				// Si le nombre est entr� est entre 1 et 10 compris,
				// affiche le nombre entr�
				if (inputNbr >=1 && inputNbr <= 10) {
					System.out.println("Vous avez entr� : " + inputNbr);
				}
			 }
		}
	}

}
