package fr.algorithmie;

import java.util.Arrays;
import java.util.OptionalDouble;

public class CalculMoyenne {

	public static void main(String[] args) {

		int[] array = {1, 15, -3, 0, 8, 7, 4, -2, 28, 7, -1, 17, 2, 3, 0, 14, -4, 8} ;
		
		// Calcul et affichage de la moyenne avec Arrays.stream
		OptionalDouble arrayAvg = Arrays.stream(array).average();
		int avgAsDouble = (int) arrayAvg.getAsDouble();
		
		System.out.println("Moyenne calcul�e avec Arrays.stream(array).average() : " + avgAsDouble);
		
		// Calcul et affichage de la moyenne avec for
		int sum = 0;
		for (int i = 0; i < array.length; i++) {
			sum += array[i];
		}
		float average = (float) sum / array.length;
		
		System.out.println("Moyenne calcul�e avec boucle for : " + average);
	}

}
