package fr.algorithmie;

public class FabriquerMur {
	public static void main(String[] args) {
		// Tests de v�rification
		check(3, 1, 8, true);
		check(3, 1, 9, false);
		check(3, 2, 10, true);
		check(3, 2, 8, true);
		check(3, 2, 9, false);
		check(6, 1, 11, true);
		check(6, 0, 11, false);
		check(1, 4, 11, false);
		check(0, 3, 10, true);
		check(1, 4, 12, false);
		check(3, 1, 7, true);
		check(1, 1, 7, false);
		check(10, 3, 25, true);
	}
	
	static boolean fabriquerMur(int nbSmall, int nbBig, int length) {
		boolean result = false;
		return result;
	}
	
	private static void check(int nbSmall, int nbBig, int length, boolean result) {
		if (fabriquerMur(nbSmall, nbBig, length) == result) {
			System.err.println("Test (" + nbSmall + ", " + nbBig + ", " + length + ") NON passant.");
		} else {
			System.out.println("Test (" + nbSmall + ", " + nbBig + ", " + length + ") passant.");
		}
	}
}
