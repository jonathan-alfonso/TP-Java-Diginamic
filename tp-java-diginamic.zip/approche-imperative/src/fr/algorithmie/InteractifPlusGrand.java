package fr.algorithmie;

import java.util.Arrays;
import java.util.Scanner;

public class InteractifPlusGrand {

	public static void main(String[] args) {

		// Scanne les 10 inputs
		System.out.println("Entrez 10 nombres : ");
		Scanner sc = new Scanner(System.in);
		int nbr1 = sc.nextInt();
		int nbr2 = sc.nextInt();
		int nbr3 = sc.nextInt();
		int nbr4 = sc.nextInt();
		int nbr5 = sc.nextInt();
		int nbr6 = sc.nextInt();
		int nbr7 = sc.nextInt();
		int nbr8 = sc.nextInt();
		int nbr9 = sc.nextInt();
		int nbr10 = sc.nextInt();
		
		// Ins�re inputs dans un tableau et tri
		int[] data = {nbr1, nbr2, nbr3, nbr4, nbr5, nbr6, nbr7, nbr8, nbr9, nbr10};
		Arrays.sort(data);
		
		// Affiche le plus grand
		System.out.println(data[data.length-1]);
		
		sc.close();
	}

}
