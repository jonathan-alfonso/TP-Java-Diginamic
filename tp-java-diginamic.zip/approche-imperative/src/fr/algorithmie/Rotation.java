package fr.algorithmie;

public class Rotation {

	public static void main(String[] args) {

		int[] array = {0, 1, 2, 3, 4, 5};
		// D�termine le nombre de fois o� l'array fait une rotation
		int rotation = 1;
		
		// Affichage tableau original
		System.out.println("Tableau original : ");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		
		// Rotation du tableau vers la droite
		for (int i = 0; i < rotation; i++) {
			int j, last;
			// Enregistre le dernier �l�ment du tableau
			last = array[array.length-1];
			
			for (j = array.length-1; j > 0; j--) {
				// D�place les �l�ments
				array[j] = array[j-1];
			}
			array[0] = last;
		}
		
		System.out.print("\n");
		
		// Affichage tableau apr�s rotation
		System.out.println("Tableau apr�s rotation : ");
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
	}

}
