package fr.algorithmie;

import java.util.Scanner;

public class InteractifTableMult {

	public static void main(String[] args) {

		System.out.println("Entrez un nombre compris entre 1 et 10 : ");
		try (Scanner scanner = new Scanner(System.in)) {
			int inputNbr = scanner.nextInt();

			while (inputNbr < 1 || inputNbr > 10) {
				System.out.println("Entrez un nombre compris entre 1 et 10 : ");
				inputNbr = scanner.nextInt();
			}

			// Si le nombre est entr� est entre 1 et 10 compris,
			// cr�e la table de multiplication et l'affiche
			if (inputNbr >= 1 && inputNbr <= 10) {
				System.out.println("Table de " + inputNbr);

				for (int i = 1; i < 11; i++) {
					System.out.println(inputNbr + " * " + i + " = " + inputNbr * i);
				}
			}
		}
	}
}
