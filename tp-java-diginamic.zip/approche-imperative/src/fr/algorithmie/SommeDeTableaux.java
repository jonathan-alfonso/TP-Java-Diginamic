package fr.algorithmie;

import java.util.Arrays;

public class SommeDeTableaux {

	public static void main(String[] args) {

		int[] array1 = {1, 15, -3, 0, 8, 7, 4, -2, 28, 7, -1, 17, 2, 3, 0, 14, -4} ;
		int[] array2 = {-1, 12, 17, 14, 5, -9, 0, 18, -6, 0, 4, -13, 5, 7, -2, 8, -1} ;
		
		// Calcul de la somme des tableaux
		int sumArray1 = Arrays.stream(array1).sum();
		int sumArray2 = Arrays.stream(array2).sum();
		
		// Affichage des sommes
		System.out.println("Somme tableau 1 : " + sumArray1);
		System.out.println("Somme tableau 2 : " + sumArray2);
		
		// Insertion dans un tableau
		int[] finalArray = {sumArray1, sumArray2};
		System.out.println("Tableau des sommes : " + finalArray[0] + " et " + finalArray[1]);
		
		// Somme du tableau final
		int sumFinalArray = Arrays.stream(finalArray).sum();
		System.out.println("Somme tableau final : " + sumFinalArray);
		
	}

}
