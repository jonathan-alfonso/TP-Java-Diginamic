package fr.algorithmie;

public class FirstLast {

	public static void main(String[] args) {

		int[] array = {3, 15, -3, 8, 7, 4, -2, 28, -1, 17, 2, 3, 0, 14, 6} ;
		boolean arrayCtrl;
		
		/*
		 * SI la longueur du tableau est sup�rieure ou �gale � 1
		 * ET
		 * SI le premier et le dernier �l�ment sont �gaux
		 * ALORS Array CTRL = true
		 * SINON Array CTRL = false
		 */
		
		if (array.length >= 1 && array[0] == array[array.length-1]) {
			arrayCtrl = true;
		} else {
			arrayCtrl = false;
		}
		
		System.out.println("Contr�le du tableau : " + arrayCtrl);

	}

}
