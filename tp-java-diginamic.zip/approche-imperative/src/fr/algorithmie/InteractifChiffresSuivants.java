package fr.algorithmie;

import java.util.Scanner;

public class InteractifChiffresSuivants {

	public static void main(String[] args) {

		// Demande un nombre et scanne l'input
		System.out.println("Entrez un nombre : ");
		try (Scanner scanner = new Scanner(System.in)) {
			int inputNbr = scanner.nextInt();
			
			for (int i = inputNbr + 1; i <= inputNbr + 10; i++) {
				System.out.print(i + " ");
			}
		}
	}

}
