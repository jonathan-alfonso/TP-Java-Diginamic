package fr.algorithmie;

import java.util.Scanner;

public class InteractifSommeArithmetique {

	public static void main(String[] args) {

		// Demande un nombre et scanne l'input
		System.out.println("Entrez un nombre : ");
		try (Scanner scanner = new Scanner(System.in)) {
			int inputNbr = scanner.nextInt();
			int sum = 0;
			
			for (int i = 1; i <= inputNbr; i++) {
				sum += i;
			}
			
			System.out.println(sum);
		}
	}
}
